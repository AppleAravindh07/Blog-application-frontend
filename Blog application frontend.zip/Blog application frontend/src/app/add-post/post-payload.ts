export class PostPayload{
  id: String;
  content: String;
  title: String;
  username: String
}
